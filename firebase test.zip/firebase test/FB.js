import { initializeApp } from "https://www.gstatic.com/firebasejs/9.1.2/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
} from "https://www.gstatic.com/firebasejs/9.1.2/firebase-auth.js";
import {
  getDatabase,
  ref,
  push,
  set,
  update,
  serverTimestamp,
} from "https://www.gstatic.com/firebasejs/9.1.2/firebase-database.js";



// Your web app's Firebase configuration // Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyCzzvz38S8clPm7j2PJUfzD84ljPcvFi3c",
  authDomain: "testvscode-8d3b4.firebaseapp.com",
  databaseURL: "https://testvscode-8d3b4-default-rtdb.firebaseio.com",
  projectId: "testvscode-8d3b4",
  storageBucket: "testvscode-8d3b4.appspot.com",
  messagingSenderId: "228782259069",
  appId: "1:228782259069:web:e3d71ca0f43d9d75782a14",
  measurementId: "G-1HH710SK1Y",
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);
let MyID;
let dataxx = {
  name: "sasa",
  timestamp: serverTimestamp(),
};

// Login
document.getElementById("loginButton").addEventListener("click", () => {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      let MyID = auth.currentUser.uid;
      console.log("Logged in as:", userCredential.user.email);
    })
    .catch((error) => {
      console.error("Login error:", error);
    });
});

// Add Data
document.getElementById("addDataButton").addEventListener("click", () => {
  const data = document.getElementById("dataField").value;
  const user = auth.currentUser;

  if (user) {
    const userId = user.uid;
    const dataRef = ref(database, "users/" + userId + "/" + "for me");

    set(dataRef, {
      data: dataxx,
    })
      .then(() => {
        console.log("Data added successfully!");
      })
      .catch((error) => {
        console.error("Error adding data:", error);
      });
  } else {
    console.log("User not logged in");
  }
});
